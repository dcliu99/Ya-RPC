package com.distribute.ya;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */
// 设置sum与uppercase方法接口
public interface YaService extends Remote {
    Float sum(Float a,Float b) throws RemoteException;
    String uppercase(String str) throws RemoteException;
}
