package com.distribute.ya.impl;

import com.distribute.ya.YaService;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */
public class YaServiceImpl extends UnicastRemoteObject implements YaService {

    public YaServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public Float sum(Float a, Float b) throws RemoteException {
        System.out.println("sum：输入参数为"+a+","+b+"。结果为"+(a+b));
        return a+b;
    }

    @Override
    public String uppercase(String str) throws RemoteException {
        System.out.println("uppercase：输入字符串为"+str);
        return str.toUpperCase();
    }
}
