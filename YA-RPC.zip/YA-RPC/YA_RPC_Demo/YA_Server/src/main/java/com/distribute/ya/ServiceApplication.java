package com.distribute.ya;

import com.distribute.ya.impl.YaServiceImpl;

import java.util.Date;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */


public class ServiceApplication {
    public static void main(String[] args) throws Exception {
        Long startTime = System.currentTimeMillis();
        System.out.println("YA-RPC:服务器启动中...."+new Date());
        // 创建服务对象
        YaService yaService = new YaServiceImpl();
        // 服务注册
        YA_RPC.registerService(YaService.class,yaService);
        Long endTime = System.currentTimeMillis();
        System.out.println("YA-RPC:服务器启动完成...."+(endTime - startTime) + "ms");
    }
}
