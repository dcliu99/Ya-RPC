package com.distribute.ya;

import org.apache.zookeeper.KeeperException;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.util.Scanner;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */
public class Client1 {
    public static void main(String[] args) throws NotBoundException, IOException, InterruptedException, KeeperException {
        // 利用YA_RPC框架实现远程过程调用
        YaService yaService = YA_RPC.getServiceProxy(YaService.class);
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("Hello,client1!");
            System.out.println("1. sum(Float,Float)");
            System.out.println("2. uppercase(String)");
            System.out.println("3. exit");
            System.out.print("请选择你要调用的服务：");
            int choose = in.nextInt();
            if (choose == 1) {
                System.out.print("请输入两个数字：");
                Float a = in.nextFloat();
                Float b = in.nextFloat();
                Float sum = yaService.sum(a, b);
                System.out.println("返回结果：" + sum);
            } else if (choose == 2){
                System.out.print("请输入一个字符串：");
                in.nextLine();
                String str = in.nextLine();
                String upperStr = yaService.uppercase(str);
                System.out.println("返回结果："+upperStr);
            }else{
                System.out.println("再见！");
                break;
            }
        }
    }
}
