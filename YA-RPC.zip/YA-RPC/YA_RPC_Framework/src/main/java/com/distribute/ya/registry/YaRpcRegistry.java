package com.distribute.ya.registry;


import com.distribute.ya.connection.ZkConnection;
import lombok.Data;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.data.Stat;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.util.List;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */
@Data
// 注册器，用于在ZooKeeper中注册服务
public class YaRpcRegistry {
    //连接对象
    private ZkConnection zkConnection;
    private String ip;
    private int port;
    // 服务注册，将rmi地址记录在zk中
    public void registerService(Class<? extends Remote> serviceInterface, Remote serviceObject) throws IOException, InterruptedException, KeeperException, KeeperException {
        // rmi://ip:port/com.distribute.ya.xxx
        String rmi = "rmi://"+ip+":"+port+"/"+serviceInterface.getName();

        // zk节点命名
        String path = "/ya_rpc/"+serviceInterface.getName();

        List<String> chirldren = zkConnection.getConnection().getChildren("/ya_rpc",false);
        //如果存在相同命名的节点，则删除再添加
        if(chirldren.contains(serviceInterface.getName())){
            Stat stat = new Stat();
            zkConnection.getConnection().getData(path,false,stat);
            zkConnection.getConnection().delete(path,stat.getCversion());
        }
        //创建节点
        zkConnection.getConnection().create(path,rmi.getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        //把服务对象在RMI的Registry中注册
        Naming.rebind(rmi,serviceObject);
    }

    // 根据接口类型，从ZK中得到RMI地址，获取服务对象
    public <T extends Remote> T getServiceProxy(Class<T> serviceInterface) throws IOException, KeeperException, InterruptedException, NotBoundException, NotBoundException {
        // 拼接zk中的节点名称
        String path = "/ya_rpc/"+serviceInterface.getName();

        // 查询节点中存储的数据并转换，也就是RMI的访问地址
        byte[] datas = zkConnection.getConnection().getData(path, false, null);
        String rmi = new String(datas);
        // 创建代理对象
        Object obj = Naming.lookup(rmi);
        return (T) obj;
    }
}
