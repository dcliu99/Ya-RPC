package com.distribute.ya.connection;

import lombok.Data;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import java.io.IOException;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */
public class ZkConnection {
    // 保存zk地址，格式 ip:port
    private String zkServer;
    // 会话超时时间
    private int sessionTimeout;

    public ZkConnection() {
        super();
        // 设置初始值
        this.zkServer = "localhost:2181";
        this.sessionTimeout = 10000;
    }
    public ZkConnection(String zkServer, int sessionTimeout) {
        this.zkServer = zkServer;
        this.sessionTimeout = sessionTimeout;
    }
    public ZooKeeper getConnection() throws IOException {
        return new ZooKeeper(zkServer,sessionTimeout,new Watcher(){
            @Override
            public void process(WatchedEvent watchedEvent){
            }
        });
    }
}
