package com.distribute.ya;

import com.distribute.ya.connection.ZkConnection;
import com.distribute.ya.registry.YaRpcRegistry;
import lombok.Data;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;

import java.io.IOException;
import java.io.InputStream;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.List;
import java.util.Properties;

/**
 * @author by 刘大川-202121081035
 * @date 2021/10/28
 */
@Data
public class YA_RPC {
    // 配置信息
    private static final Properties config = new Properties();
    // 连接对象
    private static ZkConnection connection ;
    // 注册器对象
    private static YaRpcRegistry registry;

    static {
        try {
            // 获取classpath类路径下的配置文件输入流
            InputStream input = YA_RPC.class.getClassLoader().getResourceAsStream("ya-rpc-conf.properties");
            // 读取配置文件，初始化配置信息
            config.load(input);
            String serverIp = config.getProperty("registry.ip") == null?"localhost":config.getProperty("registry.ip");
            int serverPort = config.getProperty("registry.port") == null ? 9999 : Integer.parseInt(config.getProperty("registry.port"));
            String zkServer = config.getProperty("zk.server") == null ? "localhost:2181" : config.getProperty("zk.server");
            int zkSessionTimeout = config.getProperty("zk.sessionTimeout") == null ? 10000 : Integer.parseInt(config.getProperty("zk.sessionTimeout"));

            // 创建zk连接对象
            connection = new ZkConnection(zkServer,zkSessionTimeout);
            // 创建并初始化注册器对象
            registry = new YaRpcRegistry();
            registry.setIp(serverIp);
            registry.setPort(serverPort);
            registry.setZkConnection(connection);
            // 创建一个RMI的注册器。
            LocateRegistry.createRegistry(serverPort);
            // 检查zk，若不存在节点 /ya_rpc 则创建
            List<String> children = connection.getConnection().getChildren("/", false);
            if(!children.contains("ya_rpc")){
                // 创建节点/ya_rpc
                connection.getConnection().create("/ya_rpc", null, ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (KeeperException e) {
            e.printStackTrace();
        }
    }
    // 提供服务注册和代理对象的公共方法
    public static void registerService(Class<? extends Remote> serviceInterface, Remote serviceObject) throws IOException, InterruptedException, KeeperException {
        registry.registerService(serviceInterface,serviceObject);
    }
    public static <T extends Remote> T getServiceProxy(Class<T> serviceInterface) throws IOException, KeeperException, InterruptedException, NotBoundException, NotBoundException {
        return registry.getServiceProxy(serviceInterface);
    }
}
